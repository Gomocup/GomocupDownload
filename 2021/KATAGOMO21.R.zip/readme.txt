This is a single-thread CPU version with a medium size network, much slower and weaker than GPU version.  
To save memory, I deleted something like "mutex pool","lock" in this Gomocup version. So if you set it to multithread by changing cfg file or other ways, some unknown bugs may occur.
You can get full-strength version from https://github.com/hzyhhzy/KataGo/releases after Gomocup. There are multithread version and GPU(opencl and cuda) version with an analyse interface(Lizzie yzy).  Nvidia RTX2060 is 300~600x faster(about +1000elo) than this. And there are some bigger and stronger nets. 

Katagomo is based on lightvector(David Wu)'s Katago: https://github.com/lightvector/KataGo
Code is opensourced on Github: https://github.com/hzyhhzy/KataGo/tree/gomoku

HZY
2021.5.3

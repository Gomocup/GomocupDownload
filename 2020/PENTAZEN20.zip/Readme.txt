pbrain-PentaZen20-15.exe is for board of 15 * 15 size. It supports freestyle, standard and renju rules.
pbrain-PentaZen20-20.exe is for board of 20 * 20 size. It supports freestyle rule.
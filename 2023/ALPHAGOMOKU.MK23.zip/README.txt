1. Updates
This is a CPU-only version. For full version visit https://github.com/MaciejKozarzewski/AlphaGomoku.

2. Bugs, suggestions and all other issues.
If you have found a bug, or have a suggestion for enhancement, visit https://github.com/MaciejKozarzewski/AlphaGomoku and create an issue. For all other topics you can write at alphagomoku.mk@gmail.com.

3. Supported protocols
The detailed documentation of supported protocols can be found in 'protocols.pdf' file.

4. Command line options
Run AlphaGomoku with command line argument --help (or -h) to list all possible command line arguments.

5. Configuration file
You can run automatic configuration by lauching AlphaGomoku with command line argument --configure. Note that before configuration you might need to run benchmarking.
An example configration file looks like this:
{
  "version": "5.6.0",					// specifies program version for which this config file was created.
  "protocol": "gomocup",				// specifies protocol to be used, as it cannot be changed at runtime.
  "use_logging": false,					// if set to true, the engine will save some detailed info about search results into logfile. New file is created after every START or RESTART command.
  "always_ponder": false,				// if set to true, the engine will automatically turn on pondering mode after each move.
  "swap2_openings_file": "swap2_openings.json",		// path to file with swap2 3-stone openings
  "conv_networks": {
    "freestyle": "freestyle_conv_8x128.bin",	// path to the main network used for freestyle rule.
    "standard": "standard_conv_8x128.bin",	// path to the main network used for standard rule.
    "renju": "renju_conv_8x128.bin",		// path to the main network used for renju rule.
    "caro5": "caro5_conv_8x128.bin",		// path to the main network used for caro5 (exactly five stones) rule.
    "caro6": ""					// path to the main network used for caro6 (five or more stones) rule.
  },
  "nnue_networks": {				// paths to nnue-like networks used in the alpha-beta search (currently unused)
    "freestyle": "",
    "standard": "",
    "renju": "",
    "caro5": "",
    "caro6": ""
  },
  "use_symmetries": true,	// if set to true, the engine will apply one of the possible symmetries (flips, rotations) to the board before sending it for neural network evaluation. Improves playing strength, but makes the search non-deterministic.
  "search_threads": 1,		// number of threads used by the program. This setting can be changed at runtime (depending on protocol).
  "devices": [
    {
      "device": "CPU",		// this example config uses single thread of CPU for evaluating neural network.
      "batch_size": 12		// this example config will evaluate neural network on 12 positions in parallel (can be less in some situations).
    }
  ],
  "search_config": {
    "max_batch_size": 12,			// this is maximum number of positions that will be evaluated in parallel.
    "tree_config": {
      "information_leak_threshold": 0.01,
      "initial_node_cache_size": 65536,
      "edge_bucket_size": 100000,
      "node_bucket_size": 10000
    },
    "mcts_config": {
        "edge_selector_config": {
          "policy": "puct",
          "init_to": "parent",
          "noise_type": "none",
          "noise_weight": 0.0,
          "exploration_constant": 1.0,
          "exploration_exponent": 0.5,
          "style_factor": 0.5
        },
        "max_children": 32,			// controls tree pruning, after applying "policy_expansion_threshold" to prune low policy nodes, only "max_children" of best nodes will be added to the tree. You can set this to a number larger than the board size (eg. 225 for 15x15 board) to disable pruning.
        "policy_expansion_threshold": 1.0e-4	// controls tree pruning, nodes that have lower prior policy (calculated by the network) will not be added to the tree. You can set this to 0.0 to disable pruning.
    },
    "tss_config": {
      "mode": 2,				// controls how the VCF solver is used. For 0 it only detects game end conditions, for 1 it provides static evaluation, for 2 it performs full recursive search.
      "max_positions": 1000,
      "hash_table_size": 8388608
    }
  }
}

6. Logfile details
In the logfile you can find all communication with the manager in lines starting with "Received : " and "Answered : ". Also you can find detailed info about search results, which can look like this:

########################
-----first-section------

depth=40 : S= W21 : Q=0.974640 : 0.000015 : 0.025345 : Visits=13602 : Edges=32
BEST
CROSS  (17,16) : Xq17 : S= W21 : Q=0.983135 : 0.000009 : 0.016855 : Visits=13324 : P=0.013671
CROSS  ( 9,13) : Xn9  : S= -92 : Q=0.635456 : 0.000324 : 0.364220 : Visits=189 : P=0.598268
CROSS  (16,13) : Xn16 : S=-101 : Q=0.499617 : 0.000225 : 0.500158 : Visits=19 : P=0.082760
CROSS  (17,15) : Xp17 : S= +21 : Q=0.518970 : 0.000281 : 0.480749 : Visits=12 : P=0.050572
CROSS  (17,12) : Xm17 : S= -23 : Q=0.404419 : 0.000321 : 0.595261 : Visits=11 : P=0.061011
CROSS  (16,15) : Xp16 : S=-117 : Q=0.517730 : 0.000450 : 0.481820 : Visits=8 : P=0.037454
CROSS  (17,10) : Xk17 : S= -80 : Q=0.568752 : 0.000115 : 0.431134 : Visits=5 : P=0.017153
CROSS  (10,10) : Xk10 : S=-292 : Q=0.266853 : 0.000313 : 0.732835 : Visits=5 : P=0.032967
CROSS  ( 8,11) : Xl8  : S=-141 : Q=0.437899 : 0.000329 : 0.561772 : Visits=4 : P=0.021890
CROSS  (12,16) : Xq12 : S=+117 : Q=0.595978 : 0.000207 : 0.403816 : Visits=2 : P=0.007926

Here you can see up to 10 best moves in the current position.
An example line can look like this:
CROSS  (17,16) : Xq17 : S= W21 : Q=0.983135 : 0.000009 : 0.016855 : Visits=13324 : P=0.013671

What does it mean?
"CROSS  (17,16)" is sign, row and column of a move (point 0,0 is in upper left corner).
"Xq17" is a move encoded as text, in this case this is Cross (Black) at 17-th column and 18-th row (point a0 is in upper left corner).
"S= W21" is alpha-beta score. In this case it is a sure win in 21 moves. Other values are "L" for loss, or "D" for draw or a number if the score is not proven.
"Q=0.983135 : 0.000009 : 0.016855" are three numbers, probability of win, draw and loss respectively.
"Visits=13324" is the number of MCTS simulations that traversed this move.
"P=0.013671" is prior policy assigned by the network when this position was added to the tree. It represents the probability that this move is the best one in this position (at least that is what neural network thinks about this move).

########################
-----second-section-----
Here you can find distribution of MCTS simulations over the board. For example a value of '13' means 1.3% of playouts went through this move. Sometimes, some positions will be marked with ">W<" or ">L<" or ">D<" which means that this move was proven to be win or loss or draw, respectively.
    a   b   c   d   e   f   g   h   i   j   k   l   m   n   o   p   q   r   s   t 
 0  _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   0
 1  _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   1
 2  _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   2
 3  _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   3
 4  _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   4
 5  _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   5
 6  _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   6
 7  _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   7
 8  _   _   _   _   _   _   _   _   _   _   _   _   O   O   O   X   _   _   _   _   8
 9  _   _   _   _   _   _   _   _   _   _   _   _   _   13  X   _   O   _   _   _   9
10  _   _   _   _   _   _   _   _   _   _   _   X   _   O   _   _   X   _   _   _  10
11  _   _   _   _   _   _   _   _   _   _   _   _   O   X   X   O   X   _   _   _  11
12  _   _   _   _   _   _   _   _   _   _   _   _   X   O   O   X   _   O   _   _  12
13  _   _   _   _   _   _   _   _   _   X   _   O   X   _   O   _   X   _   _   _  13
14  _   _   _   _   _   _   _   _   O   _   X   X   X   O   O   X   _   O   _   _  14
15  _   _   _   _   _   _   _   _   X   O   _   O   O   X   _   O   _   _   _   _  15
16  _   _   _   _   _   _   _   _   _   _   _   _   _    1  X   _   X   _   _   _  16
17  _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _  W21  _   _   _  17
18  _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _  18
19  _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _   _  19
    a   b   c   d   e   f   g   h   i   j   k   l   m   n   o   p   q   r   s   t 

########################
-----third-section------
Here you can see pricipal variation.

CROSS  (17,16) : Xq17 : S= W21 : Q=0.983135 : 0.000009 : 0.016855 : Visits=13324 : P=0.013671
CIRCLE (15,16) : Oq15 : S= L18 : Q=0.012740 : 0.000005 : 0.987255 : Visits=8301 : P=0.878230
CROSS  (17,15) : Xp17 : S= W17 : Q=0.994129 : 0.000003 : 0.005869 : Visits=8094 : P=0.519155
CIRCLE (18,16) : Oq18 : S= L16 : Q=0.005850 : 0.000003 : 0.994147 : Visits=8093 : P=1.000000
CROSS  (17,14) : Xo17 : S= W15 : Q=0.999934 : 0.000000 : 0.000066 : Visits=7782 : P=0.466217
CIRCLE (17,13) : On17 : S= L14 : Q=0.000000 : 0.000000 : 1.000000 : Visits=1695 : P=0.218040
CROSS  (16,13) : Xn16 : S= W13 : Q=1.000000 : 0.000000 : 0.000000 : Visits=1694 : P=1.000000

########################
-----fourth-section-----
Here you can find the timing of various stages of the search. Typically they have following format: "name" : total time : number of events : average time of each event. On Windows the clock resolution is sometimes too low to capture most of the events, you will see 0.0s then.

----NNEvaluator----
total samples = 873
avg batch size = 2.025522			// this is the average number of positions evaluated by the neural network in each step.
pack    = 0.001443s : 431 : 3.347564 us		// this is the time of packing the data to network input
launch  = 0.000000s : 0 : 0.000000 us		// this is the time of launching the neural network evaluation
compute = 4.680242s : 431 : 10.859031 ms	// this is the time spent on computation
wait    = 0.000000s : 0 : 0.000000 us		// this is the time spent on waiting until the computations are complete (only relevant for asynchronous evaluation with GPUs)
unpack  = 0.002133s : 431 : 4.948260 us		// this is the time of unpacking the data from network output

----SearchStats----
nb_duplicate_nodes     = 0			// in parallel MCTS it can happen that the same node will be evaluated more than once (it is ok). This is the number of such nodes.
nb_information_leaks   = 218			// number of mismatch of evaluation between graph edge and node.
nb_wasted_expansions   = 0			// number of unnecessarily expanded nodes (can happen from time to time in parallel MCTS).
nb_proven_states       = 12573			// number of visited states that have already been proven
nb_network_evaluations = 873			// number of positions evaluated by the neural network
nb_node_count          = 965			// number of evaluated nodes
select   = 0.034291s : 13756 : 2.492781 us	// time of selection phase in MCTS
solve    = 0.374076s : 965 : 387.643834 us	// time used by VCF solver
schedule = 0.001101s : 965 : 1.141347 us	// time used to schedule positions for neural network evaluation
generate = 0.005064s : 965 : 5.247358 us	// time used to generate legal actions for each position
expand   = 0.002326s : 965 : 2.410674 us	// time of tree expansion phase in MCTS
backup   = 0.001310s : 965 : 1.357617 us	// time of backup phase in MCTS

----NodeCacheStats----
load factor = 0.032000
stored nodes    = 2103
allocated nodes = 40000
stored edges    = 30913
allocated edges = 700000
seek     = 0.084930s : 201805 : 0.420850 us	// time used for seeking an element in the cache
insert   = 0.094467s : 88673 : 1.065341 us	// time used for inserting elements to the cache
remove   = 0.000016s : 17 : 0.929412 us		// time used for removing elements from the cache
resize   = 0.000000s : 0 : 0.000000 us		// time used for cache resize
cleanup  = 0.048654s : 17 : 2.862006 ms		// time used for cache cleanup (after each position change)

memory usage = 1MB				// estimated memory usage					
